﻿namespace $safeprojectname$.ViewModels
{
    using $safeprojectname$.ViewModels.Base;

    public class MainViewModel : ViewModelBase
    {
    }
}
