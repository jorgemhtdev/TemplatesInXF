﻿namespace $safeprojectname$.Styles
{
    using Xamarin.Forms.Xaml;

    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DefaultTheme
    {
        public DefaultTheme()
        {
            InitializeComponent();
        }
    }
}