﻿namespace $safeprojectname$.Features
{
    using $safeprojectname$.Base;

    public class OnboardingViewModel : BaseViewModel
    {
    }
}
