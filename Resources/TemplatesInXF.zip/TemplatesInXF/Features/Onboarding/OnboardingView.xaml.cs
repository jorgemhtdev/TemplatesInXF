﻿namespace $safeprojectname$.Features
{
    using Xamarin.Forms.Xaml;

    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OnboardingView 
    {
        public OnboardingView()
        {
            InitializeComponent();
        }
    }
}