﻿namespace $safeprojectname$
{
    public static class AppSettings
    {
        //App Center
        const string defaultAppCenterAndroid = "";
        const string defaultAppCenteriOS = "";

        public static string ApiBaseUrl = "#";
    }
}
