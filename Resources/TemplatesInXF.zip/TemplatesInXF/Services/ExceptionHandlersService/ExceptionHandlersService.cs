﻿namespace $safeprojectname$.Services
{
    public interface IExceptionHandlersService
    {
        void ShowExceptionFile();
    }
}
