﻿namespace $safeprojectname$.Services
{
    public interface INavigationService
    {
    }
}