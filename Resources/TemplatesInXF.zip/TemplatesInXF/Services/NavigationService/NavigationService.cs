﻿[assembly: Xamarin.Forms.Dependency(typeof($safeprojectname$.Services.NavigationService))]
namespace $safeprojectname$.Services
{
    public class NavigationService : INavigationService
    {
    }
}