﻿#if MOCK
[assembly: Xamarin.Forms.Dependency(typeof($safeprojectname$.Services.MockApiService))]
#endif
namespace $safeprojectname$.Services
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public class MockApiService : IApiService
    {
        public Task<bool> GetExampleAsync(Dictionary<string, string> exampleData)
        {
            return Task.FromResult(true);
        }
    }
}
