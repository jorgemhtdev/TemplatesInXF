﻿namespace $safeprojectname$.Services
{
    public static class ApiServiceKeys
    {
        public static string ApiServiceBaseUrl = "";
    }
}
